/**
 * request-id.ts
 *
 * Generates and provides X-Request-ID headers for every outbound request.
 * A unique ID per request allows correlation of frontend logs with backend
 * structured logs across the entire execution chain.
 */

export const X_REQUEST_ID_HEADER = "X-Request-ID" as const;

export function generateRequestId(): string {
  return crypto.randomUUID();
}
