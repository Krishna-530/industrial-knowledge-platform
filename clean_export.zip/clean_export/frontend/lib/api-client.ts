import { authenticatedRequest } from "@/lib/network/auth-interceptor";
import type { RequestOptions } from "@/lib/network/http-client";

export async function apiClient<T>(options: Omit<RequestOptions, "path"> & { endpoint: string }): Promise<T> {
  const { endpoint, ...rest } = options;
  return authenticatedRequest<T>({
    ...rest,
    path: endpoint.startsWith("/") ? endpoint : `/${endpoint}`,
  });
}
