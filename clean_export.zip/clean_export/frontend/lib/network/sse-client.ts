import type { SseEvent } from "@/types/api";
import { getAccessToken } from "./auth-token-store";
import { generateRequestId, X_REQUEST_ID_HEADER } from "./request-id";

const BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "";

export interface SseClientOptions {
  path: string;
  body: Record<string, unknown>;
  signal: AbortSignal;
}

/**
 * sse-client.ts
 *
 * SSE consumer using fetch + ReadableStream.
 * Uses fetch (not EventSource) to support the Authorization Bearer header.
 * Parses the raw "id/event/data" SSE wire format into typed SseEvent objects.
 * Yields events as an AsyncGenerator — caller controls cancellation via AbortSignal.
 */
export async function* sseRequest<T = unknown>(
  options: SseClientOptions
): AsyncGenerator<SseEvent<T>> {
  const { path, body, signal } = options;
  const token = getAccessToken();
  const requestId = generateRequestId();

  const response = await fetch(`${BASE_URL}${path}`, {
    method: "POST",
    signal,
    headers: {
      "Content-Type": "application/json",
      "Accept": "text/event-stream",
      [X_REQUEST_ID_HEADER]: requestId,
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(body),
  });

  if (!response.ok || !response.body) {
    throw new Error(`SSE connection failed: HTTP ${response.status}`);
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();

  let buffer = "";
  let eventId = "";
  let eventName = "";
  let dataLines: string[] = [];

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });

    const lines = buffer.split("\n");
    // Keep the last incomplete line in the buffer
    buffer = lines.pop() ?? "";

    for (const line of lines) {
      if (line === "") {
        // Empty line — dispatch the accumulated event
        if (dataLines.length > 0) {
          try {
            const data = JSON.parse(dataLines.join("\n")) as SseEvent<T>;
            yield {
              stream_id: data.stream_id ?? "",
              id:        eventId,
              event:     eventName || "message",
              data:      data.data ?? (data as unknown as T),
              retry:     data.retry,
            };
          } catch {
            // Malformed JSON in SSE data — skip
          }
          eventId = "";
          eventName = "";
          dataLines = [];
        }
        continue;
      }

      if (line.startsWith("id:")) {
        eventId = line.slice(3).trim();
      } else if (line.startsWith("event:")) {
        eventName = line.slice(6).trim();
      } else if (line.startsWith("data:")) {
        dataLines.push(line.slice(5).trim());
      } else if (line.startsWith("retry:")) {
        // retry directive — browser handles automatically; we note it but don't act
      }
    }
  }
}
