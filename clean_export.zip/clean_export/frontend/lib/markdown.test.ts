import { renderMarkdown, renderCodeBlock } from "./markdown";

describe("Markdown Pipeline", () => {
  it("renders safe markdown to HTML", () => {
    const input = "# Hello\n\nThis is **bold** and *italic*.";
    const result = renderMarkdown(input);
    expect(result).toContain("<h1>Hello</h1>");
    expect(result).toContain("<strong>bold</strong>");
    expect(result).toContain("<em>italic</em>");
  });

  it("sanitizes dangerous HTML (XSS prevention)", () => {
    const input = "Hello <script>alert('xss')</script> <img src=x onerror=alert('xss')>";
    const result = renderMarkdown(input);
    expect(result).not.toContain("<script>");
    expect(result).not.toContain("onerror");
    expect(result).toContain("Hello");
    expect(result).toContain("<img src=\"x\">");
  });

  it("formats code blocks with syntax highlighting classes", () => {
    const input = "```python\nprint('hello')\n```";
    const result = renderMarkdown(input);
    expect(result).toContain("<pre>");
    expect(result).toContain("<code class=\"language-python\">");
    expect(result).toContain("print('hello')");
  });

  it("escapes code using renderCodeBlock manually", () => {
    const result = renderCodeBlock("<div>hello & goodbye</div>", "html");
    expect(result).toContain("<pre><code class=\"language-html\">");
    expect(result).toContain("&lt;div&gt;hello &amp; goodbye&lt;/div&gt;");
  });
});
