import { marked } from "marked";
import DOMPurify from "dompurify";

/**
 * lib/markdown.ts — Mandatory LLM output rendering pipeline.
 *
 * ALL AI-generated content MUST pass through renderMarkdown() before rendering.
 * No component may bypass this pipeline. Using dangerouslySetInnerHTML with
 * unsanitized strings is a critical XSS vulnerability.
 *
 * Pipeline:
 *   raw string → marked (parse Markdown → HTML) → DOMPurify (sanitize) → safe HTML string
 */

// Configure marked for safe, synchronous output
marked.setOptions({
  async: false,
  gfm: true,    // GitHub Flavored Markdown (tables, strikethrough, etc.)
  breaks: true, // Treat single newlines as <br>
});

const DOMPURIFY_CONFIG = {
  ALLOWED_TAGS: [
    "p", "br", "strong", "em", "u", "s", "del",
    "h1", "h2", "h3", "h4", "h5", "h6",
    "ul", "ol", "li",
    "blockquote", "pre", "code",
    "table", "thead", "tbody", "tr", "th", "td",
    "a", "img", "hr",
    "span", "div",
  ],
  ALLOWED_ATTR: [
    "href", "src", "alt", "title", "class",
    "target", "rel",
  ],
  ALLOW_DATA_ATTR: false,
};

/**
 * renderMarkdown(raw) — Parse and sanitize LLM Markdown output.
 * Returns a sanitized HTML string safe for use with dangerouslySetInnerHTML.
 *
 * This is the ONLY permitted use of dangerouslySetInnerHTML in the application.
 */
export function renderMarkdown(raw: string): string {
  const html = marked.parse(raw) as string;
  return DOMPurify.sanitize(html, DOMPURIFY_CONFIG) as string;
}

/**
 * renderCodeBlock — Render a code string as a preformatted block.
 * Used for syntax-highlighted code within the markdown output.
 */
export function renderCodeBlock(code: string, language?: string): string {
  const escaped = code
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
  const langClass = language ? ` class="language-${language}"` : "";
  return DOMPurify.sanitize(`<pre><code${langClass}>${escaped}</code></pre>`, DOMPURIFY_CONFIG) as string;
}
