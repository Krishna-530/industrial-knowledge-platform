import type { User } from "@/types/api";
import { Permission } from "./permissions";

/**
 * lib/auth/authorization.ts — Pure authorization functions.
 *
 * All functions accept a User (or null) and return boolean.
 * Zero React — these are plain TypeScript, fully unit-testable without rendering.
 *
 * RULE: Components must NEVER inspect user.role or user.permissions directly.
 *       Use these functions via usePermission() instead.
 */

function hasPermission(user: User | null, permission: Permission): boolean {
  if (!user || !Array.isArray(user.permissions)) return false;
  return user.permissions.includes(permission);
}

export function canUploadDocuments(user: User | null): boolean {
  return hasPermission(user, Permission.UPLOAD_DOCUMENT);
}

export function canDeleteDocuments(user: User | null): boolean {
  return hasPermission(user, Permission.DELETE_DOCUMENT);
}

export function canViewAnalytics(user: User | null): boolean {
  return hasPermission(user, Permission.VIEW_ANALYTICS);
}

export function canManageUsers(user: User | null): boolean {
  return hasPermission(user, Permission.MANAGE_USERS);
}

export function canManageWorkspace(user: User | null): boolean {
  return hasPermission(user, Permission.MANAGE_WORKSPACE);
}

export function canViewAssets(user: User | null): boolean {
  return hasPermission(user, Permission.VIEW_ASSETS);
}

export function canViewChat(user: User | null): boolean {
  return hasPermission(user, Permission.VIEW_CHAT);
}

// Generic helper for the usePermission hook
export function checkPermission(user: User | null, permission: Permission): boolean {
  return hasPermission(user, permission);
}
