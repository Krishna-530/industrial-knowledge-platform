/**
 * lib/network/index.ts — Public API for the networking module.
 *
 * Only these exports are accessible to feature hooks and contexts.
 * Internal modules (auth-token-store, request-id, http-client, error-parser)
 * are implementation details — import them ONLY within lib/network/*.
 */

export { authenticatedRequest } from "./auth-interceptor";
export { sseRequest, type SseClientOptions } from "./sse-client";
export { HttpError } from "./http-client";
export type { RequestOptions } from "./http-client";
