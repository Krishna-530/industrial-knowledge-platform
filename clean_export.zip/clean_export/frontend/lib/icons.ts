/**
 * lib/icons.ts — Frozen icon registry.
 *
 * All icons used across the application are re-exported from this single file.
 * Components import from "@/lib/icons" — NEVER directly from "lucide-react".
 * Switching icon packs in future requires changes to this file only.
 */

export {
  LayoutDashboard  as DashboardIcon,
  MessageSquare    as ChatIcon,
  Package          as AssetIcon,
  FileText         as DocumentIcon,
  BarChart2        as AnalyticsIcon,
  Settings         as SettingsIcon,
  User             as UserIcon,
  Upload           as UploadIcon,
  Trash2           as TrashIcon,
  Search           as SearchIcon,
  Bell             as BellIcon,
  Sun              as SunIcon,
  Moon             as MoonIcon,
  Monitor          as MonitorIcon,
  ChevronLeft      as ChevronLeftIcon,
  ChevronRight     as ChevronRightIcon,
  ChevronDown      as ChevronDownIcon,
  X                as CloseIcon,
  Check            as CheckIcon,
  AlertCircle      as AlertCircleIcon,
  AlertTriangle    as AlertTriangleIcon,
  Info             as InfoIcon,
  Loader2          as SpinnerIcon,
  Plus             as PlusIcon,
  ExternalLink     as ExternalLinkIcon,
  Copy             as CopyIcon,
  RefreshCw        as RefreshIcon,
  LogOut           as LogOutIcon,
  Wrench           as ToolIcon,
  Quote            as CitationIcon,
  Menu             as MenuIcon,
  X                as XIcon,
} from "lucide-react";
