import { parseErrorResponse } from "@/lib/network/error-parser";
import type { ApiError } from "@/types/api";

/**
 * api-response.ts
 *
 * Exposes utilities to handle API responses.
 * Enforces mapping to frontend DTOs and normalizing errors.
 */

export { parseErrorResponse };
export type { ApiError };
