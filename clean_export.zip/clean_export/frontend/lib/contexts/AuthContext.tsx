"use client";

import React, { createContext, useCallback, useEffect, useMemo, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import type { AuthContextValue, AuthStatus, LoginCredentials } from "@/types/app";
import type { User } from "@/types/api";
import { httpRequest } from "@/lib/network/http-client";
import { setAccessToken, clearAccessToken } from "@/lib/network/auth-token-store";
import { authenticatedRequest } from "@/lib/network/auth-interceptor";
import { authQueryKeys } from "@/features/auth/query";

const SESSION_MARKER_KEY = "session-active";

const defaultValue: AuthContextValue = {
  status:          "initializing",
  isAuthenticated: false,
  login:           async () => undefined,
  logout:          async () => undefined,
};

export const AuthContext = createContext<AuthContextValue>(defaultValue);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [status, setStatus] = useState<AuthStatus>("initializing");
  const queryClient = useQueryClient();

  // ── Session restore on mount ──────────────────────────────────────────────

  useEffect(() => {
    let cancelled = false;

    async function restore() {
      setStatus("restoring");
      try {
        const refreshToken = localStorage.getItem("refresh_token");
        if (!refreshToken) throw new Error("No refresh token available");

        // Step 1: Token refresh using refresh token in Authorization header
        const refreshData = await httpRequest<{ access_token: string; refresh_token: string }>({
          path:        "/auth/refresh",
          method:      "POST",
          headers:     { Authorization: `Bearer ${refreshToken}` },
        });
        setAccessToken(refreshData.access_token);
        localStorage.setItem("refresh_token", refreshData.refresh_token);

        // Step 2: Fetch user identity into React Query Cache
        setStatus("hydrating");
        await queryClient.fetchQuery({
          queryKey: authQueryKeys.me,
          queryFn: () => authenticatedRequest<User>({ path: "/users/me", method: "GET" }),
        });

        if (!cancelled) {
          setStatus("authenticated");
          localStorage.setItem(SESSION_MARKER_KEY, "1");
        }
      } catch {
        if (!cancelled) {
          clearAccessToken();
          queryClient.removeQueries({ queryKey: authQueryKeys.me });
          setStatus("unauthenticated");
        }
      }
    }

    restore();
    return () => { cancelled = true; };
  }, [queryClient]);

  // ── Multi-tab logout detection ────────────────────────────────────────────

  useEffect(() => {
    function handleStorage(e: StorageEvent) {
      if (e.key === SESSION_MARKER_KEY && e.newValue !== "1") {
        clearAccessToken();
        queryClient.removeQueries({ queryKey: authQueryKeys.me });
        setStatus("unauthenticated");
        localStorage.removeItem("refresh_token");
      }
    }
    window.addEventListener("storage", handleStorage);
    return () => window.removeEventListener("storage", handleStorage);
  }, [queryClient]);

  // ── session-expired event from auth-interceptor ───────────────────────────

  useEffect(() => {
    function handleExpired() {
      queryClient.removeQueries({ queryKey: authQueryKeys.me });
      setStatus("unauthenticated");
      localStorage.removeItem(SESSION_MARKER_KEY);
      localStorage.removeItem("refresh_token");
    }
    window.addEventListener("session-expired", handleExpired);
    return () => window.removeEventListener("session-expired", handleExpired);
  }, [queryClient]);

  // ── login ─────────────────────────────────────────────────────────────────

  const login = useCallback(async (credentials: LoginCredentials) => {
    setStatus("authenticating");
    try {
      const data = await httpRequest<{ access_token: string; refresh_token: string }>({
        path:        "/auth/login",
        method:      "POST",
        credentials: "include",
        body:        JSON.stringify(credentials),
      });
      setAccessToken(data.access_token);
      localStorage.setItem("refresh_token", data.refresh_token);

      setStatus("hydrating");
      const me = await queryClient.fetchQuery({
        queryKey: authQueryKeys.me,
        queryFn: () => authenticatedRequest<User>({ path: "/users/me", method: "GET" }),
      });
      
      setStatus("authenticated");
      localStorage.setItem(SESSION_MARKER_KEY, "1");
    } catch (error) {
      clearAccessToken();
      queryClient.removeQueries({ queryKey: authQueryKeys.me });
      setStatus("unauthenticated");
      localStorage.removeItem("refresh_token");
      throw error;
    }
  }, [queryClient]);

  // ── logout ────────────────────────────────────────────────────────────────

  const logout = useCallback(async () => {
    clearAccessToken();
    queryClient.clear(); // Wipe all sensitive data from cache
    setStatus("unauthenticated");
    localStorage.setItem(SESSION_MARKER_KEY, "0"); // signals other tabs
    localStorage.removeItem("refresh_token");
    try {
      await httpRequest({ path: "/auth/logout", method: "POST", credentials: "include" });
    } catch {
      // Best-effort — local state is already cleared
    }
  }, [queryClient]);

  // ── Context value ─────────────────────────────────────────────────────────

  const value = useMemo<AuthContextValue>(
    () => ({ status, isAuthenticated: status === "authenticated", login, logout }),
    [status, login, logout]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

