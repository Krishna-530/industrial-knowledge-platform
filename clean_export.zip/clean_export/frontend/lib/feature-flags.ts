import type { FeatureFlags } from "@/types/app";

/**
 * lib/feature-flags.ts — Frozen feature flag registry.
 *
 * All feature switches are read from environment variables here.
 * No component may reference process.env.NEXT_PUBLIC_* directly.
 * Usage: import { featureFlags } from "@/lib/feature-flags";
 *        if (featureFlags.ENABLE_ANALYTICS) { ... }
 */

function flag(envKey: string): boolean {
  return process.env[envKey] === "true";
}

export const featureFlags: Readonly<FeatureFlags> = Object.freeze({
  ENABLE_GRAPH_VIEW:        flag("NEXT_PUBLIC_ENABLE_GRAPH_VIEW"),
  ENABLE_ANALYTICS:         flag("NEXT_PUBLIC_ENABLE_ANALYTICS"),
  ENABLE_MULTI_AGENT:       flag("NEXT_PUBLIC_ENABLE_MULTI_AGENT"),
  ENABLE_KNOWLEDGE_GRAPH:   flag("NEXT_PUBLIC_ENABLE_KNOWLEDGE_GRAPH"),
  ENABLE_EXPERIMENTAL_CHAT: flag("NEXT_PUBLIC_ENABLE_EXPERIMENTAL_CHAT"),
});
