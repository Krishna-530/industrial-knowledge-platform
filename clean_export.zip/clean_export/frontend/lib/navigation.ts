import type { NavItem } from "@/types/app";
import { Permission } from "@/lib/auth/permissions";

/**
 * lib/navigation.ts — Frozen navigation registry.
 *
 * Sidebar renders this array — it contains zero hardcoded routes.
 * Order in the array is the render order.
 * Items with a `permission` field are hidden when the user lacks that permission.
 * Items with a `featureFlag` field are hidden when that flag is disabled.
 */

export const navigationItems: readonly NavItem[] = Object.freeze([
  {
    title:       "Dashboard",
    href:        "/dashboard",
    iconName:    "DashboardIcon",
  },
  {
    title:       "Chat",
    href:        "/chat",
    iconName:    "ChatIcon",
    permission:  Permission.VIEW_CHAT,
  },
  {
    title:       "Assets",
    href:        "/assets",
    iconName:    "AssetIcon",
    permission:  Permission.VIEW_ASSETS,
  },
  {
    title:       "Documents",
    href:        "/documents",
    iconName:    "DocumentIcon",
  },
  {
    title:       "Analytics",
    href:        "/analytics",
    iconName:    "AnalyticsIcon",
    permission:  Permission.VIEW_ANALYTICS,
    featureFlag: "ENABLE_ANALYTICS",
  },
  {
    title:       "Settings",
    href:        "/settings",
    iconName:    "SettingsIcon",
  },
]);
