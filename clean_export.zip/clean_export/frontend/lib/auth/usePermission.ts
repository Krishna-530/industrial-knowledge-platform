"use client";

import { useCurrentUser } from "@/features/auth/hooks";
import { checkPermission } from "./authorization";
import { Permission } from "./permissions";

/**
 * usePermission — React hook for permission-based conditional rendering.
 *
 * Usage:
 *   const canDelete = usePermission(Permission.DELETE_DOCUMENT);
 *   if (canDelete) { ... }
 */
export function usePermission(permission: Permission): boolean {
  const { data: user } = useCurrentUser();
  return checkPermission(user || null, permission);
}

export { Permission };
