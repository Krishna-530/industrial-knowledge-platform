import type { ApiError } from "@/types/api";
import { parseErrorResponse } from "./error-parser";
import { generateRequestId, X_REQUEST_ID_HEADER } from "./request-id";

const BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "";
const TIMEOUT_MS = 30_000;

export class HttpError extends Error {
  constructor(public readonly apiError: ApiError) {
    super(apiError.detail);
    this.name = "HttpError";
  }
}

export interface RequestOptions extends RequestInit {
  /** Path relative to NEXT_PUBLIC_API_URL, e.g. "/auth/login" */
  path: string;
  /** Override the default 30s timeout */
  timeoutMs?: number;
}

/**
 * Core fetch wrapper.
 * Responsibilities: base URL, timeout, X-Request-ID injection, error parsing.
 * Does NOT inject auth tokens — that is auth-interceptor's job.
 */
export async function httpRequest<T>(options: RequestOptions): Promise<T> {
  const { path, timeoutMs = TIMEOUT_MS, headers, signal: externalSignal, ...rest } = options;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  // Merge external signal with our timeout signal
  if (externalSignal) {
    externalSignal.addEventListener("abort", () => controller.abort());
  }

  const requestId = generateRequestId();

  try {
    const response = await fetch(`${BASE_URL}${path}`, {
      ...rest,
      signal: controller.signal,
      headers: {
        "Content-Type": "application/json",
        [X_REQUEST_ID_HEADER]: requestId,
        ...headers,
      },
    });

    if (!response.ok) {
      const apiError = await parseErrorResponse(response);
      throw new HttpError(apiError);
    }

    // Handle 204 No Content
    if (response.status === 204) {
      return undefined as T;
    }

    return response.json() as Promise<T>;
  } finally {
    clearTimeout(timeoutId);
  }
}
