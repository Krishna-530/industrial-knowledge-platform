import type { ApiError } from "@/types/api";

/**
 * Parses a fetch Response into a typed ApiError.
 * Handles RFC 7807 JSON bodies and falls back gracefully for non-JSON errors.
 */
export async function parseErrorResponse(response: Response): Promise<ApiError> {
  const contentType = response.headers.get("content-type") ?? "";

  if (contentType.includes("application/json") || contentType.includes("application/problem+json")) {
    try {
      const body = await response.json();
      return {
        type:     body.type     ?? "about:blank",
        title:    body.title    ?? response.statusText,
        status:   body.status   ?? response.status,
        detail:   body.detail   ?? "An unexpected error occurred.",
        instance: body.instance,
      };
    } catch {
      // JSON parse failed — fall through to generic error
    }
  }

  return {
    type:   "about:blank",
    title:  response.statusText || "Error",
    status: response.status,
    detail: `HTTP ${response.status}: ${response.statusText}`,
  };
}
