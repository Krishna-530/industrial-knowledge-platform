/**
 * auth-token-store.ts
 *
 * Module-scoped access token storage.
 * The token is held in a plain variable — never in localStorage or sessionStorage.
 * Only the networking layer (auth-interceptor, sse-client) may import this module.
 * React components must NEVER import this directly.
 */

let _accessToken: string | null = null;

export function getAccessToken(): string | null {
  return _accessToken;
}

export function setAccessToken(token: string): void {
  _accessToken = token;
}

export function clearAccessToken(): void {
  _accessToken = null;
}
