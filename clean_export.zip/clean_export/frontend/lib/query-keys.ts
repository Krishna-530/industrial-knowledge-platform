/**
 * lib/query-keys.ts — Frozen React Query key registry.
 *
 * RULES:
 * - All feature hooks MUST import keys from this file.
 * - No feature may define an inline string array as a query key.
 * - Keys are hierarchical: invalidating a parent key invalidates all children.
 */

export const dashboardKeys = {
  all: ["dashboard"] as const,
  overview: () => [...dashboardKeys.all, "overview"] as const,
} as const;

export const assetKeys = {
  all: ["assets"] as const,
  lists: () => [...assetKeys.all, "list"] as const,
  list: (filters: string) => [...assetKeys.lists(), { filters }] as const,
  details: () => [...assetKeys.all, "detail"] as const,
  detail: (id: string) => [...assetKeys.details(), id] as const,
  facts: (id: string) => [...assetKeys.detail(id), "facts"] as const,
  findings: (id: string) => [...assetKeys.detail(id), "findings"] as const,
} as const;

export const documentKeys = {
  all: ["documents"] as const,
  lists: () => [...documentKeys.all, "list"] as const,
  list: (filters: string) => [...documentKeys.lists(), { filters }] as const,
  details: () => [...documentKeys.all, "detail"] as const,
  detail: (id: string) => [...documentKeys.details(), id] as const,
} as const;

export const analyticsKeys = {
  all: ["analytics"] as const,
  conflicts: (filters: string) => [...analyticsKeys.all, "conflicts", { filters }] as const,
  corroborations: (filters: string) => [...analyticsKeys.all, "corroborations", { filters }] as const,
  duplicates: (filters: string) => [...analyticsKeys.all, "duplicates", { filters }] as const,
} as const;

export const chatKeys = {
  all: ["chat"] as const,
  lists: () => [...chatKeys.all, "list"] as const,
  detail: (id: string) => [...chatKeys.all, "detail", id] as const,
  messages: (id: string) => [...chatKeys.all, "messages", id] as const,
} as const;

export const usersKeys = {
  all: ["users"] as const,
  lists: () => [...usersKeys.all, "list"] as const,
  list: (filters: { limit: number; offset: number }) => [...usersKeys.lists(), filters] as const,
  details: () => [...usersKeys.all, "detail"] as const,
  detail: (id: string) => [...usersKeys.details(), id] as const,
} as const;

export const rolesKeys = {
  all: ["roles"] as const,
  lists: () => [...rolesKeys.all, "list"] as const,
  list: (filters: { limit: number; offset: number }) => [...rolesKeys.lists(), filters] as const,
  details: () => [...rolesKeys.all, "detail"] as const,
  detail: (id: string) => [...rolesKeys.details(), id] as const,
} as const;

// Legacy export to avoid breaking existing modules during transition
export const queryKeys = {
  dashboard: dashboardKeys.all,
  assets: assetKeys.all,
  asset: assetKeys.detail,
  assetFacts: assetKeys.facts,
  assetFindings: assetKeys.findings,
  conversations: ["conversations"] as const,
  conversation: (id: string) => ["conversations", id] as const,
  documents: documentKeys.all,
  document: documentKeys.detail,
  analytics: analyticsKeys.all,
  me: ["auth", "me"] as const,
} as const;

export type QueryKeys = typeof queryKeys;
