/**
 * lib/date.ts — Frozen date formatting utilities.
 *
 * All date formatting in the application goes through this module.
 * Components must NEVER use new Date().toLocaleString() or similar directly.
 * Implemented with native Intl — no date-fns dependency.
 */

const relativeFormatter = new Intl.RelativeTimeFormat("en", { numeric: "auto" });

const THRESHOLDS: [number, Intl.RelativeTimeFormatUnit][] = [
  [60,         "second"],
  [3600,       "minute"],
  [86400,      "hour"],
  [86400 * 7,  "day"],
  [86400 * 30, "week"],
  [86400 * 365,"month"],
  [Infinity,   "year"],
];

/**
 * formatRelative("2026-07-13T10:00:00Z") → "2 hours ago"
 */
export function formatRelative(date: string | Date): string {
  const d = typeof date === "string" ? new Date(date) : date;
  const diffSeconds = (d.getTime() - Date.now()) / 1000;
  const absDiff = Math.abs(diffSeconds);

  let prev = 1;
  for (const [threshold, unit] of THRESHOLDS) {
    if (absDiff < threshold) {
      const value = Math.round(diffSeconds / prev);
      return relativeFormatter.format(value, unit);
    }
    prev = threshold;
  }
  return formatAbsolute(d);
}

const absoluteFormatter = new Intl.DateTimeFormat("en-GB", {
  day:    "2-digit",
  month:  "short",
  year:   "numeric",
  hour:   "2-digit",
  minute: "2-digit",
  hour12: false,
});

/**
 * formatAbsolute("2026-07-13T10:00:00Z") → "13 Jul 2026, 10:00"
 */
export function formatAbsolute(date: string | Date): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return absoluteFormatter.format(d);
}

/**
 * formatTimestamp — ISO 8601 string for use in <time datetime="..."> attributes
 */
export function formatTimestamp(date: string | Date): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toISOString();
}

/**
 * formatDuration(1532) → "1m 32s"
 * Formats ConversationCompletedEvent.latency_ms into a human-readable string.
 */
export function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  const totalSeconds = Math.floor(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  if (minutes === 0) return `${seconds}s`;
  return `${minutes}m ${seconds}s`;
}
