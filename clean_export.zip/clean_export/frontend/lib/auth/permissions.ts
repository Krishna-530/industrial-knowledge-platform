/**
 * lib/auth/permissions.ts — Frozen Permission enum.
 *
 * Values must mirror the backend Permission constants exactly.
 * Components must NEVER inspect user.role or user.permissions directly.
 * Use usePermission(Permission.X) instead.
 */

export enum Permission {
  UPLOAD_DOCUMENT   = "upload_document",
  DELETE_DOCUMENT   = "delete_document",
  VIEW_ANALYTICS    = "view_analytics",
  MANAGE_USERS      = "manage_users",
  MANAGE_WORKSPACE  = "manage_workspace",
  VIEW_ASSETS       = "view_assets",
  VIEW_CHAT         = "view_chat",
}
