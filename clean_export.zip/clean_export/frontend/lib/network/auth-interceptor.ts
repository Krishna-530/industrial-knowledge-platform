import { httpRequest, HttpError, type RequestOptions } from "./http-client";
import { getAccessToken, setAccessToken, clearAccessToken } from "./auth-token-store";

/**
 * auth-interceptor.ts
 *
 * Wraps httpRequest with:
 * - Bearer token injection from auth-token-store
 * - Single-flight 401 → silent refresh → one retry
 * - On refresh failure: clears token, dispatches "session-expired" event
 */

// Single-flight lock: one pending refresh promise shared across all concurrent 401s
let _refreshPromise: Promise<void> | null = null;

async function attemptRefresh(): Promise<void> {
  if (_refreshPromise) {
    // Another request is already refreshing — wait for it
    return _refreshPromise;
  }

  _refreshPromise = (async () => {
    try {
      const refreshToken = localStorage.getItem("refresh_token");
      if (!refreshToken) throw new Error("No refresh token available");
      
      const data = await httpRequest<{ access_token: string, refresh_token: string }>({
        path: "/auth/refresh",
        method: "POST",
        headers: { Authorization: `Bearer ${refreshToken}` },
      });
      setAccessToken(data.access_token);
      localStorage.setItem("refresh_token", data.refresh_token);
    } catch {
      clearAccessToken();
      // Notify AuthContext via custom event — it will transition to UNAUTHENTICATED
      if (typeof window !== "undefined") {
        window.dispatchEvent(new CustomEvent("session-expired"));
      }
      throw new Error("Session expired");
    } finally {
      _refreshPromise = null;
    }
  })();

  return _refreshPromise;
}

export async function authenticatedRequest<T>(options: RequestOptions): Promise<T> {
  const token = getAccessToken();

  const headersWithAuth = {
    ...(options.headers as Record<string, string> | undefined),
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };

  try {
    return await httpRequest<T>({ ...options, headers: headersWithAuth });
  } catch (error) {
    if (error instanceof HttpError && error.apiError.status === 401) {
      // Attempt silent token refresh (single-flight)
      await attemptRefresh();

      // Retry original request with new token
      const newToken = getAccessToken();
      return httpRequest<T>({
        ...options,
        headers: {
          ...(options.headers as Record<string, string> | undefined),
          ...(newToken ? { Authorization: `Bearer ${newToken}` } : {}),
        },
      });
    }
    throw error;
  }
}
